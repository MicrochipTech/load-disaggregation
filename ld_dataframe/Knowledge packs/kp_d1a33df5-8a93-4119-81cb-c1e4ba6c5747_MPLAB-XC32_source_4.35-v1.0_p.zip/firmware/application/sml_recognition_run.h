#ifndef __SML_RECOGNITION_RUN_H__
#define __SML_RECOGNITION_RUN_H__
#include "kb.h"

int32_t sml_recognition_run(int16_t *data, int32_t num_sensors);

#endif //__SML_RECOGNITION_RUN_H__
